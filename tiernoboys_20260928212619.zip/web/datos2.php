<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recibir datos del formulario
    $comida     = $_POST["fcomida"]     ?? "";
    $pasatiempo = $_POST["fpasatiempo"] ?? "";
    $cancion    = $_POST["fcancion"]    ?? "";
    $brainrot   = $_POST["brainrot"]    ?? "";

    // Checkboxes (pueden ser varios)
    if (isset($_POST["tarea"])) {
        $tareas = implode(", ", $_POST["tarea"]);
    } else {
        $tareas = "ninguna";
    }

    // Crear texto a guardar
    $registro = "Comida: $comida | Pasatiempo: $pasatiempo | Cancion: $cancion | Brainrot: $brainrot | Tareas: $tareas\n";

    // Guardar en archivo
    file_put_contents("datos_guardados.txt", $registro, FILE_APPEND);

    echo "<h2>Datos guardados correctamente</h2>";
    echo "Comida favorita: " . htmlspecialchars($comida) . "<br>";
    echo "Pasatiempo favorito: " . htmlspecialchars($pasatiempo) . "<br>";
    echo "Cancion favorita: " . htmlspecialchars($cancion) . "<br>";
    echo "Brainrot favorito: " . htmlspecialchars($brainrot) . "<br>";
    echo "Tareas: " . htmlspecialchars($tareas) . "<br>";
    echo "<br><a href='index.html'>Volver</a>";

}

?>