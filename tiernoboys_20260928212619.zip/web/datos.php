<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $comida = $_POST["fcomida"] ?? "";
    $artista = $_POST["fartista"] ?? "";
    $videojuego = $_POST["fvideojuego"] ?? "";
    $Brainrot = $_POST["Brainrot"] ?? "";
    $tareas = $_POST["tarea"] ?? [];

    echo "<h2>Info enviada con �xito</h2>";
    echo "Comida favorita: " . htmlspecialchars($comida) . "<br>";
    echo "Artista favorito: " . htmlspecialchars($artista) . "<br>";
    echo "Videojuego favorito: " . htmlspecialchars($videojuego) . "<br>";
    echo "Brainrot favorito: " . htmlspecialchars($Brainrot) . "<br>";

    echo "Tareas seleccionadas:<br>";

    if (!empty($tareas)) {
        foreach ($tareas as $tarea) {
            echo "- " . htmlspecialchars($tarea) . "<br>";
        }
    } else {
        echo "No seleccionaste ninguna tarea.";
    }

} else {
    echo "No se ha enviado nada";
}
?>